<?php include 'db/db.php'; ?>
<?php include 'process.php'; ?>
<?php include 'header.php'; ?>
<?php //include 'spemak/include/head.php'; ?>

<div class="container">
  <h1 class="my-4">Simple Cart (Core PHP)</h1>

  <div class="row">
    <div class="col-md-4">
      <div class="card" style="width: 18rem;">
        <img src="img/product.jpg" class="card-img-top">

        <div class="card-body">
          <h5 class="card-title">Product 1</h5>
          <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore excepturi quam quia quo alias iste magni et.</p>
          <a href="index.php?pro_id=1" class="btn btn-success">Add to Cart</a>
        </div>
      </div>
    </div>


    
             <!-- Product Start-->
             <div class="col-lg-4 col-md-6 col-12 mb-60">
                  
                    <div class="product">
                        <!-- Image Wrapper -->
                        <div class="image">
                            <!-- Image -->
                            <a href="" class="img"><img src="img/product.jpg" alt="Product"></a>
                            <!-- Wishlist -->
                            <a href="#" class="wishlist"><i class="fa fa-heart-o"></i></a>
                            <!-- Label -->
                            <span class="label">New</span>
                        </div>
                        <!-- Content -->
                        <div class="content">
                            <!-- Head Content -->
                            <div class="head fix">
                               
                                <!-- Title & Category -->
                                <div class="title-category float-left">
                                    <h5 class="title"><a href="product-details.html">Amazon AED Card</a></h5>
                                </div>
                                <!-- Price -->
                                <div class="price float-right">
                                    <span class="new">$100</span>
                                </div>
                            </div>
                            <!-- Action Button -->
                            <div class="action-button fix">
                                <a name="add_to_cart" href="index.php?pro_id=4">add to cart</a>
                            </div>   
                        </div>
                    </div>
                </div><!-- Product End-->

  </div>

</div>
<?php // include 'footer.php'; ?>